@extends('layouts.app')

@section('title', 'Edit Product')
@section('page-title', 'Edit Product')

@section('content')
<div class="space-y-6">
    
    <!-- Header -->
    <div class="flex items-center justify-between">
        <div>
            <h3 class="text-lg font-semibold text-gray-800">Edit Product</h3>
            <p class="text-sm text-gray-600">Update product information</p>
        </div>
        <a 
            href="{{ route('products.index') }}" 
            class="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition"
        >
            <i class="fas fa-arrow-left mr-2"></i>Back to Products
        </a>
    </div>

    <!-- Form -->
    <form action="{{ route('products.update', $product) }}" method="POST" enctype="multipart/form-data" class="bg-white rounded-xl shadow-md p-6">
        @csrf
        @method('PUT')

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <!-- Product Name -->
            <div class="md:col-span-2">
                <label for="name" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-tag text-blue-600 mr-2"></i>Product Name *
                </label>
                <input 
                    type="text" 
                    id="name" 
                    name="name" 
                    value="{{ old('name', $product->name) }}"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('name') border-red-500 @enderror" 
                    required
                >
                @error('name')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- SKU / Barcode (same field) -->
            <div class="md:col-span-2">
                <label for="sku" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-barcode text-blue-600 mr-2"></i>SKU / Barcode
                </label>
                <input 
                    type="text" 
                    id="sku" 
                    name="sku" 
                    value="{{ old('sku', $product->sku) }}"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('sku') border-red-500 @enderror" 
                    placeholder="Auto-generated if blank (e.g., PRD241109-001)"
                >
                <p class="text-xs text-gray-500 mt-1">
                    <i class="fas fa-info-circle mr-1"></i>This will be used as both SKU and Barcode
                </p>
                @error('sku')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Category -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-th-large text-blue-600 mr-2"></i>Categories
                </label>
                <div id="categories-wrapper" class="space-y-2">
                    @php
                        $selectedCategories = old('categories', $product->categories->pluck('id')->toArray());
                        if(empty($selectedCategories)) $selectedCategories = [null];
                    @endphp
                    @foreach($selectedCategories as $selectedCategory)
                    <div class="flex gap-2 category-row">
                        <select name="categories[]" class="category-select flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <option value="">Select Category</option>
                            @foreach($categories as $category)
                                <option value="{{ $category->id }}" {{ $selectedCategory == $category->id ? 'selected' : '' }}>
                                    {{ $category->name }}
                                </option>
                            @endforeach
                        </select>
                        <button type="button" onclick="removeRow(this)" class="px-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition remove-btn {{ count($selectedCategories) > 1 ? '' : 'hidden' }}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                    @endforeach
                </div>
                <div class="flex flex-wrap items-center gap-3 mt-2">
                    <button type="button" onclick="addCategoryRow()" class="text-xs text-blue-600 hover:text-blue-800 font-medium">
                        <i class="fas fa-plus-circle mr-1"></i>Add Another
                    </button>
                    <button type="button" onclick="openCategoryModal()" class="text-xs text-green-600 hover:text-green-800 font-medium">
                        <i class="fas fa-plus mr-1"></i>New Category
                    </button>
                </div>
                @error('categories') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>

            <!-- Brand -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-certificate text-blue-600 mr-2"></i>Brands
                </label>
                <div id="brands-wrapper" class="space-y-2">
                    @php
                        $selectedBrands = old('brands', $product->brands->pluck('id')->toArray());
                        if(empty($selectedBrands)) $selectedBrands = [null];
                    @endphp
                    @foreach($selectedBrands as $selectedBrand)
                    <div class="flex gap-2 brand-row">
                        <select name="brands[]" class="brand-select flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                            <option value="">Select Brand</option>
                            @foreach($brands as $brand)
                                <option value="{{ $brand->id }}" {{ $selectedBrand == $brand->id ? 'selected' : '' }}>
                                    {{ $brand->name }}
                                </option>
                            @endforeach
                        </select>
                        <button type="button" onclick="removeRow(this)" class="px-3 py-2 bg-red-100 text-red-600 rounded-lg hover:bg-red-200 transition remove-btn {{ count($selectedBrands) > 1 ? '' : 'hidden' }}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                    @endforeach
                </div>
                <div class="flex flex-wrap items-center gap-3 mt-2">
                    <button type="button" onclick="addBrandRow()" class="text-xs text-blue-600 hover:text-blue-800 font-medium">
                        <i class="fas fa-plus-circle mr-1"></i>Add Another
                    </button>
                    <button type="button" onclick="openBrandModal()" class="text-xs text-green-600 hover:text-green-800 font-medium">
                        <i class="fas fa-plus mr-1"></i>New Brand
                    </button>
                </div>
                @error('brands') <p class="text-red-500 text-xs mt-1">{{ $message }}</p> @enderror
            </div>

            <!-- Unit -->
            <div>
                <label for="unit_id" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-ruler text-blue-600 mr-2"></i>Unit *
                </label>
                <select 
                    id="unit_id" 
                    name="unit_id" 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('unit_id') border-red-500 @enderror" 
                    required
                >
                    <option value="">Select Unit</option>
                    @foreach($units as $unit)
                        <option value="{{ $unit->id }}" {{ old('unit_id', $product->unit_id) == $unit->id ? 'selected' : '' }}>
                            {{ $unit->name }}
                        </option>
                    @endforeach
                </select>
                @error('unit_id')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Visible Units (Price Display) -->
            <div class="md:col-span-2">
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-eye text-blue-600 mr-2"></i>Show Unit Prices For
                </label>
                <p class="text-xs text-gray-500 mb-2">Uncheck units you do not want to display in the product list. Leave all checked to show prices for every unit.</p>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-2">
                    @php($selectedUnits = old('visible_units', $product->visible_units))
                    @foreach($units as $u)
                        <label class="flex items-center space-x-2 px-2 py-1 border rounded">
                            <input type="checkbox" name="visible_units[]" value="{{ $u->id }}" class="text-blue-600 rounded"
                                {{ (is_array($selectedUnits) ? in_array($u->id, $selectedUnits) : true) ? 'checked' : '' }}>
                            @php($m = rtrim(rtrim(number_format((float)$u->base_unit_multiplier, 3, '.', ''), '0'), '.'))
                            <span class="text-xs text-gray-700">{{ $u->short_name }} (x{{ $m }})</span>
                        </label>
                    @endforeach
                </div>
            </div>

            <!-- Cost Price -->
            <div>
                <label for="cost_price" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-dollar-sign text-blue-600 mr-2"></i>Cost Price *
                </label>
                <input 
                    type="number" 
                    step="0.01" 
                    id="cost_price" 
                    name="cost_price" 
                    value="{{ old('cost_price', $product->cost_price) }}"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('cost_price') border-red-500 @enderror" 
                    required
                >
                @error('cost_price')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Profit Margin -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-chart-line text-blue-600 mr-2"></i>Profit Margin
                </label>
                <p class="text-xs text-gray-500 mb-3">Enter either percentage or fixed amount; both fields are editable and will auto-sync.</p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <input 
                        type="number" 
                        id="profit_margin_percent" 
                        step="0.01" 
                        min="0"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                        placeholder="Enter profit margin %"
                        oninput="onPercentageChange()"
                    >
                    <input 
                        type="number" 
                        id="profit_margin_fixed" 
                        step="0.01" 
                        min="0"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                        placeholder="Enter fixed amount"
                        oninput="onFixedAmountChange()"
                    >
                </div>
            </div>

            <!-- VAT -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-receipt text-green-600 mr-2"></i>VAT
                </label>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <input type="text" disabled value="{{ ($vatEnabled ?? false) ? 'Enabled' : 'Disabled' }}" class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50">
                        <p class="text-xs text-gray-500 mt-1">Configured in Settings</p>
                    </div>
                    <div>
                        <input type="text" disabled value="Rate: {{ number_format($vatRate ?? 0, 2) }}%" class="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50">
                        <p class="text-xs text-gray-500 mt-1">Used for price calculation</p>
                    </div>
                </div>
                <div class="mt-3">
                    <label class="block text-xs font-semibold text-gray-600 mb-2">Selling Price VAT Type</label>
                    <select id="vat_type" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500">
                        <option value="exclusive" selected>Exclusive (VAT added on top)</option>
                        <option value="inclusive">Inclusive (Price includes VAT)</option>
                    </select>
                </div>
            </div>

            <!-- Selling Price -->
            <div>
                <label for="selling_price" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-money-bill-wave text-blue-600 mr-2"></i>Selling Price *
                </label>
                <input 
                    type="number" 
                    step="0.01" 
                    id="selling_price" 
                    name="selling_price" 
                    value="{{ old('selling_price', $product->selling_price) }}"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('selling_price') border-red-500 @enderror" 
                    required
                >
                @error('selling_price')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Stock Quantity -->
            <div>
                <label for="stock_quantity" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-boxes text-blue-600 mr-2"></i>Stock Quantity *
                </label>
                <input 
                    type="number" 
                    id="stock_quantity" 
                    name="stock_quantity" 
                    value="{{ old('stock_quantity', $product->stock_quantity) }}"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('stock_quantity') border-red-500 @enderror" 
                    required
                >
                @error('stock_quantity')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Alert Quantity -->
            <div>
                <label for="alert_quantity" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-bell text-blue-600 mr-2"></i>Alert Quantity
                </label>
                <input 
                    type="number" 
                    id="alert_quantity" 
                    name="alert_quantity" 
                    value="{{ old('alert_quantity', $product->alert_quantity) }}"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('alert_quantity') border-red-500 @enderror"
                >
                @error('alert_quantity')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Description -->
            <div class="md:col-span-2">
                <label for="description" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-align-left text-blue-600 mr-2"></i>Description
                </label>
                <textarea 
                    id="description" 
                    name="description" 
                    rows="3" 
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('description') border-red-500 @enderror"
                >{{ old('description', $product->description) }}</textarea>
                @error('description')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Current Image -->
            @if($product->image)
            <div class="md:col-span-2">
                <label class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-image text-blue-600 mr-2"></i>Current Image
                </label>
                <div class="flex items-center space-x-4">
                    <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}" class="w-24 h-24 object-cover rounded-lg border border-gray-300">
                    <div>
                        <p class="text-sm text-gray-600">Upload a new image to replace the current one</p>
                    </div>
                </div>
            </div>
            @endif

            <!-- Image Upload -->
            <div class="md:col-span-2">
                <label for="image" class="block text-sm font-semibold text-gray-700 mb-2">
                    <i class="fas fa-image text-blue-600 mr-2"></i>Product Image {{ $product->image ? '(Replace)' : '' }}
                </label>
                <input 
                    type="file" 
                    id="image" 
                    name="image" 
                    accept="image/*"
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('image') border-red-500 @enderror"
                >
                @error('image')
                    <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Is Active -->
            <div class="md:col-span-2">
                <label class="flex items-center space-x-3">
                    <input 
                        type="checkbox" 
                        name="is_active" 
                        value="1"
                        {{ old('is_active', $product->is_active) ? 'checked' : '' }}
                        class="w-5 h-5 text-blue-600 border-gray-300 rounded focus:ring-2 focus:ring-blue-500"
                    >
                    <span class="text-sm font-semibold text-gray-700">
                        <i class="fas fa-toggle-on text-blue-600 mr-2"></i>Active Product
                    </span>
                </label>
            </div>

        </div>

        <!-- Submit Buttons -->
        <div class="flex items-center justify-end space-x-4 mt-6 pt-6 border-t border-gray-200">
            <a 
                href="{{ route('products.index') }}" 
                class="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition"
            >
                Cancel
            </a>
            <button 
                type="submit" 
                class="px-6 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition shadow-lg"
            >
                <i class="fas fa-save mr-2"></i>Update Product
            </button>
        </div>
    </form>

</div>

<!-- Category Modal -->
<div id="categoryModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-2xl max-w-md w-full">
        <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-4 text-white rounded-t-xl flex justify-between items-center">
            <h3 class="text-lg font-bold"><i class="fas fa-folder mr-2"></i>Add New Category</h3>
            <button onclick="closeCategoryModal()" class="text-white hover:text-gray-200">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <form id="categoryForm" class="p-6 space-y-4">
            @csrf
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Category Name *</label>
                <input type="text" id="category_name" name="name" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500" required>
                <p id="category_error" class="text-red-500 text-xs mt-1 hidden"></p>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                <textarea id="category_description" name="description" rows="3" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
            </div>
            <div class="flex gap-3 pt-4">
                <button type="submit" class="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold">
                    <i class="fas fa-save mr-2"></i>Save
                </button>
                <button type="button" onclick="closeCategoryModal()" class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition font-semibold">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Brand Modal -->
<div id="brandModal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-xl shadow-2xl max-w-md w-full">
        <div class="bg-gradient-to-r from-blue-600 to-blue-700 p-4 text-white rounded-t-xl flex justify-between items-center">
            <h3 class="text-lg font-bold"><i class="fas fa-copyright mr-2"></i>Add New Brand</h3>
            <button onclick="closeBrandModal()" class="text-white hover:text-gray-200">
                <i class="fas fa-times text-xl"></i>
            </button>
        </div>
        <form id="brandForm" class="p-6 space-y-4">
            @csrf
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Brand Name *</label>
                <input type="text" id="brand_name" name="name" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500" required>
                <p id="brand_error" class="text-red-500 text-xs mt-1 hidden"></p>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                <textarea id="brand_description" name="description" rows="3" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
            </div>
            <div class="flex gap-3 pt-4">
                <button type="submit" class="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition font-semibold">
                    <i class="fas fa-save mr-2"></i>Save
                </button>
                <button type="button" onclick="closeBrandModal()" class="flex-1 px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition font-semibold">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Dynamic Row Functions
function addCategoryRow() {
    const wrapper = document.getElementById('categories-wrapper');
    const firstRow = wrapper.querySelector('.category-row');
    const newRow = firstRow.cloneNode(true);
    
    // Reset selection
    newRow.querySelector('select').value = "";
    
    // Show remove button
    newRow.querySelector('.remove-btn').classList.remove('hidden');
    
    wrapper.appendChild(newRow);
    updateRemoveButtons('categories-wrapper');
}

function addBrandRow() {
    const wrapper = document.getElementById('brands-wrapper');
    const firstRow = wrapper.querySelector('.brand-row');
    const newRow = firstRow.cloneNode(true);
    
    newRow.querySelector('select').value = "";
    newRow.querySelector('.remove-btn').classList.remove('hidden');
    
    wrapper.appendChild(newRow);
    updateRemoveButtons('brands-wrapper');
}

function removeRow(btn) {
    const row = btn.closest('.flex'); // .category-row or .brand-row
    const wrapper = row.parentElement;
    if (wrapper.children.length > 1) {
        row.remove();
        updateRemoveButtons(wrapper.id);
    }
}

function updateRemoveButtons(wrapperId) {
    const wrapper = document.getElementById(wrapperId);
    const rows = wrapper.children;
    const showRemove = rows.length > 1;
    
    Array.from(rows).forEach(row => {
        const btn = row.querySelector('.remove-btn');
        if (showRemove) {
            btn.classList.remove('hidden');
        } else {
            btn.classList.add('hidden');
        }
    });
}

// Simple Toast Function
function showToast(type, message) {
    const toast = document.createElement('div');
    toast.className = `fixed top-4 right-4 z-50 px-4 py-3 rounded shadow-lg text-white transition-opacity duration-500 ${type === 'success' ? 'bg-green-600' : 'bg-red-600'}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// Category Modal Functions
function openCategoryModal() {
    document.getElementById('categoryModal').classList.remove('hidden');
    document.getElementById('category_name').value = '';
    document.getElementById('category_description').value = '';
    document.getElementById('category_error').classList.add('hidden');
}

function closeCategoryModal() {
    document.getElementById('categoryModal').classList.add('hidden');
}

document.getElementById('categoryForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const response = await fetch('{{ route("categories.store") }}', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || formData.get('_token')
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Add to all dropdowns
            const selects = document.querySelectorAll('.category-select');
            selects.forEach(select => {
                const option = new Option(data.category.name, data.category.id, false, false);
                select.add(option);
            });
            
            // Select in the last dropdown (or create new row if last is occupied)
            const wrapper = document.getElementById('categories-wrapper');
            const lastRow = wrapper.lastElementChild;
            const lastSelect = lastRow.querySelector('select');
            
            if (lastSelect.value) {
                addCategoryRow();
                const newLastSelect = wrapper.lastElementChild.querySelector('select');
                newLastSelect.value = data.category.id;
            } else {
                lastSelect.value = data.category.id;
            }
            
            closeCategoryModal();
            showToast('success', 'Category created successfully!');
        } else {
            document.getElementById('category_error').textContent = data.message || 'Error creating category';
            document.getElementById('category_error').classList.remove('hidden');
        }
    } catch (error) {
        document.getElementById('category_error').textContent = 'Error creating category';
        document.getElementById('category_error').classList.remove('hidden');
    }
});

// Brand Modal Functions
function openBrandModal() {
    document.getElementById('brandModal').classList.remove('hidden');
    document.getElementById('brand_name').value = '';
    document.getElementById('brand_description').value = '';
    document.getElementById('brand_error').classList.add('hidden');
}

function closeBrandModal() {
    document.getElementById('brandModal').classList.add('hidden');
}

document.getElementById('brandForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    
    try {
        const response = await fetch('{{ route("brands.store") }}', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content || formData.get('_token')
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            const selects = document.querySelectorAll('.brand-select');
            selects.forEach(select => {
                const option = new Option(data.brand.name, data.brand.id, false, false);
                select.add(option);
            });

            const wrapper = document.getElementById('brands-wrapper');
            const lastRow = wrapper.lastElementChild;
            const lastSelect = lastRow.querySelector('select');
            
            if (lastSelect.value) {
                addBrandRow();
                const newLastSelect = wrapper.lastElementChild.querySelector('select');
                newLastSelect.value = data.brand.id;
            } else {
                lastSelect.value = data.brand.id;
            }
            
            closeBrandModal();
            showToast('success', 'Brand created successfully!');
        } else {
            document.getElementById('brand_error').textContent = data.message || 'Error creating brand';
            document.getElementById('brand_error').classList.remove('hidden');
        }
    } catch (error) {
        document.getElementById('brand_error').textContent = 'Error creating brand';
        document.getElementById('brand_error').classList.remove('hidden');
    }
});

function onPercentageChange() {
    const costPrice = parseFloat(document.getElementById('cost_price').value) || 0;
    const percentage = parseFloat(document.getElementById('profit_margin_percent').value) || 0;
    if (costPrice > 0 && percentage >= 0) {
        const fixedAmount = costPrice * (percentage / 100);
        document.getElementById('profit_margin_fixed').value = fixedAmount.toFixed(2);

        const baseSelling = costPrice + fixedAmount;
        const vatRate = parseFloat({{ json_encode($vatRate ?? 0) }});
        const vatEnabled = Boolean({{ json_encode($vatEnabled ?? false) }});
        const vatType = document.getElementById('vat_type') ? document.getElementById('vat_type').value : 'exclusive';
        let finalSelling = baseSelling;
        if (vatEnabled) {
            finalSelling = vatType === 'exclusive' ? baseSelling * (1 + (vatRate / 100)) : baseSelling;
        }
        document.getElementById('selling_price').value = finalSelling.toFixed(2);
    } else {
        document.getElementById('profit_margin_fixed').value = '';
        document.getElementById('selling_price').value = costPrice.toFixed(2);
    }
}

function onFixedAmountChange() {
    const costPrice = parseFloat(document.getElementById('cost_price').value) || 0;
    const fixedAmount = parseFloat(document.getElementById('profit_margin_fixed').value) || 0;
    if (costPrice > 0 && fixedAmount >= 0) {
        const percentage = (fixedAmount / costPrice) * 100;
        document.getElementById('profit_margin_percent').value = percentage.toFixed(2);

        const baseSelling = costPrice + fixedAmount;
        const vatRate = parseFloat({{ json_encode($vatRate ?? 0) }});
        const vatEnabled = Boolean({{ json_encode($vatEnabled ?? false) }});
        const vatType = document.getElementById('vat_type') ? document.getElementById('vat_type').value : 'exclusive';
        let finalSelling = baseSelling;
        if (vatEnabled) {
            finalSelling = vatType === 'exclusive' ? baseSelling * (1 + (vatRate / 100)) : baseSelling;
        }
        document.getElementById('selling_price').value = finalSelling.toFixed(2);
    } else {
        document.getElementById('profit_margin_percent').value = '';
        document.getElementById('selling_price').value = costPrice.toFixed(2);
    }
}

function onCostPriceChange() {
    const fixedAmount = document.getElementById('profit_margin_fixed').value;
    const percentage = document.getElementById('profit_margin_percent').value;
    if (fixedAmount !== '') { onFixedAmountChange(); return; }
    if (percentage !== '') { onPercentageChange(); return; }
    const costPrice = parseFloat(document.getElementById('cost_price').value) || 0;
    document.getElementById('selling_price').value = costPrice.toFixed(2);
}

document.getElementById('cost_price').addEventListener('input', onCostPriceChange);
const vatTypeEl = document.getElementById('vat_type');
if (vatTypeEl) {
    vatTypeEl.addEventListener('change', () => {
        const spVal = document.getElementById('selling_price').value;
        if (spVal !== '') {
            onSellingPriceChange();
        } else {
            onCostPriceChange();
        }
    });
}

function onSellingPriceChange() {
    const costPrice = parseFloat(document.getElementById('cost_price').value) || 0;
    const sellingFinal = parseFloat(document.getElementById('selling_price').value) || 0;
    const vatRate = parseFloat({{ json_encode($vatRate ?? 0) }});
    const vatEnabled = Boolean({{ json_encode($vatEnabled ?? false) }});
    const vatType = document.getElementById('vat_type') ? document.getElementById('vat_type').value : 'exclusive';

    let baseSelling = sellingFinal;
    if (vatEnabled && vatType === 'exclusive') {
        baseSelling = sellingFinal / (1 + (vatRate / 100));
    }

    const fixedAmount = baseSelling - costPrice;
    const percentage = costPrice > 0 ? (fixedAmount / costPrice) * 100 : 0;

    if (!isNaN(fixedAmount)) {
        document.getElementById('profit_margin_fixed').value = fixedAmount.toFixed(2);
    }
    if (!isNaN(percentage)) {
        document.getElementById('profit_margin_percent').value = percentage.toFixed(2);
    }
}

document.getElementById('selling_price').addEventListener('input', onSellingPriceChange);
</script>
@endsection
